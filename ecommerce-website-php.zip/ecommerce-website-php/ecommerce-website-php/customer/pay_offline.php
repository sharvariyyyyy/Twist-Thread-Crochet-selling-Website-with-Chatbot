<center><!-- center Starts -->

<h1> Pay OffLine Using Method  </h1>

<p class="text-muted" >

If you have any questions, please feel free to <a href="../contact.php" >contact us,</a> our customer service center is working for you 24/7.

</p>

</center><!-- center Ends -->

<hr>


<div class="table-responsive" ><!-- table-responsive Starts -->

<table class="table table-bordered table-hover table-striped" ><!-- table table-bordered table-hover table-striped Starts -->

<thead><!-- thead Starts -->

<tr>

<th> Bank Account Details </th>

<th> UPI, GPay Details: </th>

<th> SBI Branch Details: </th>

</tr>

</thead><!-- thead Ends -->

<tbody><!-- tbody Starts -->

<tr>

<td> Bank Name:SBI Account No:03333333 Branch Code:0342 Branch Name:Ghatkopar	 </td>

<td> NIC#001230006 Mobile No:8454902104, Name:Saumitra </td>

<td> Full Name:Saumitra, Mobile No:8454902104, Name:Saumitra, Country:IND, N.I.C No:011234567
</td>


</tr>

</tbody><!-- tbody Ends -->


</table><!-- table table-bordered table-hover table-striped Ends -->

</div><!-- table-responsive Ends -->
