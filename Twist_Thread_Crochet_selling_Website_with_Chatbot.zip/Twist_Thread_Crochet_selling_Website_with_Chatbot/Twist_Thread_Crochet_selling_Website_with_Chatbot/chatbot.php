<?php
// chatbot.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $message = strtolower(trim($_POST['message'] ?? ''));

    // Simple FAQ pairs
    $faq = [
    'hello' => 'Hi there! How can I help you with crochet today?',
    'hi' => 'Hello! Need help with crochet?',
    'bye' => 'Goodbye! Happy crocheting!',
    'thank you' => 'You’re welcome! Glad I could help 😊',
    'thanks' => 'Anytime! Happy to help you with crochet.',
    'what is crochet' => 'Crochet is a craft where you use a hook to create fabric from yarn.',
    'what do I need to start crochet' => 'You need yarn, a crochet hook, and scissors to start.',
    'what is a slip knot' => 'A slip knot is the first knot you make to start crocheting.',
    'how to make a chain stitch' => 'Wrap the yarn and pull it through the loop on your hook to make a chain.',
    'how to hold a crochet hook' => 'Hold it like a pencil or a knife, whichever feels comfortable.',
    'how to hold yarn' => 'Wrap the yarn around your fingers to control the tension.',
    'what yarn is best' => 'Acrylic yarn is best for beginners because it is easy to use and affordable.',
    'can I use knitting yarn for crochet' => 'Yes! Knitting and crochet yarns are usually the same.',
    'what are crochet hooks made of' => 'They are made of metal, plastic, bamboo, or wood.',
    'how to fix yarn tangles' => 'Gently unwind the yarn and keep it in a ball.',
    'how to store yarn' => 'Use boxes or bags to keep yarn clean and untangled.',
    'how to wash crochet items' => 'Hand wash gently with cold water and mild soap.',
    'what is your name' => 'I’m CrochetBot, your friendly crochet assistant!',
    'do you like crochet' => 'I love crochet! Helping with your projects makes me happy.',
    'who made you' => 'I was made by a crochet enthusiast just like you!',
    'what is a crochet hook' => 'It’s a tool with a hook at the end used to pull yarn through loops.',
    'how to start crochet' => 'Get yarn and a hook, then learn stitches like chain and single crochet.',
    'what hook size should I use' => 'Check the yarn label — it usually recommends a hook size.',
    'how to read crochet patterns' => 'Patterns use abbreviations; start simple and learn each one.',
    'what are common crochet stitches' => 'Chain, single crochet, double crochet, and slip stitch are common.',
    'how to count stitches' => 'Count each “V” shape in your row to track your stitches.',
    'how to join yarn colors' => 'Finish one yarn, tie the new yarn in, and keep stitching.',
    'how to increase stitches' => 'Work two stitches into one to add more stitches.',
    'how to decrease stitches' => 'Crochet two stitches together to reduce the number of stitches.',
    'how to crochet in the round' => 'Start with a chain or magic ring, then crochet in a circle.',
    'can crochet be machine washed' => 'Most handmade items should be hand washed for safety.',
    'what is gauge in crochet' => 'Gauge is how many stitches and rows fit in an inch — important for sizing.',
    'what is a magic ring' => 'It’s a way to start crochet in the round with a tight center.',
    'how to block crochet items' => 'Wet your item and lay it flat to shape and dry.',
    'how long does it take to learn crochet' => 'With practice, most people get comfortable in a few weeks.',
    'how to make a scarf' => 'Start with a chain, use one stitch like single or double crochet.',
    'what is the best yarn for baby blankets' => 'Soft yarn like cotton or bamboo blends are perfect for babies.',
    'how to crochet faster' => 'Practice and use ergonomic tools to increase speed.',
    'can I sell my crochet items' => 'Yes! Many people sell on Etsy or at local craft fairs.',
    'how to fix mistakes in crochet' => 'Unravel the stitches back to the mistake and redo that part.',
    'how to make a granny square' => 'Start in the round and use clusters of double crochet.',
    'how to design my own crochet pattern' => 'Plan it out with stitch charts, gauge, and test swatches first.',
    'what is Tunisian crochet' => 'It’s a technique between knitting and crochet using a special hook.',
    'how to convert knitting patterns to crochet' => 'It’s tricky — you must match gauge and stitch density closely.',
    'how to use a crochet chart' => 'Charts use symbols; each symbol is a different stitch.',
    'how to make amigurumi' => 'Use single crochet in the round with tight stitches and stuffing.',
    'what is filet crochet' => 'Filet crochet creates images using open and closed mesh squares.',
    'how to do tapestry crochet' => 'Carry multiple yarn colors and work them into the stitches.',
    'what is surface crochet' => 'It’s a way to embroider or outline shapes on top of finished fabric.',
    'how to crochet cables' => 'Use front and back post stitches to create raised cable designs.',
    'how to crochet lace' => 'Use fine thread and open stitch patterns like chains and picots.',
    'how to do corner-to-corner (C2C)' => 'Start in one corner and increase; decrease on the opposite side.',
    'how to read crochet symbols' => 'Each symbol stands for a stitch; refer to a legend or chart key.',
    'how to size a crochet garment' => 'Use gauge swatches and take body measurements before starting.',
    'how to adjust a pattern for size' => 'Change hook size or stitch count to alter the final size.',
    'how to join motifs' => 'Sew or crochet motifs together using slip stitch or whipstitch.',
    'how to write a crochet pattern' => 'Include materials, gauge, abbreviations, and row-by-row instructions.',
    'how to crochet with beads' => 'Pre-string the beads or insert them into stitches as you go.',
    'how to create texture in crochet' => 'Use post stitches, bobbles, and clusters for texture.',
    'how to make 3D crochet projects' => 'Use shaping, increases, and tight stitches to create 3D forms.',
    'how to analyze stitch multiples' => 'Identify the stitch repeat (like a multiple of 6 + 2) for your project.',
    ];

    $response = "Sorry, I didn't understand that. Can you ask something else?";

    foreach ($faq as $key => $answer) {
        if (strpos($message, $key) !== false) {
            $response = $answer;
            break;
        }
    }

    echo json_encode(['reply' => $response]);
    exit;
}
?>
