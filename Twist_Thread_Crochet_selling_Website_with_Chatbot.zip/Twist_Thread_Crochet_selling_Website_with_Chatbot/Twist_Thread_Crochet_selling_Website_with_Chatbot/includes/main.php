<?php
//session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link href="../customer/styles/bootstrap.min.css" rel="stylesheet">
  <link href="../customer/styles/backend.css" rel="stylesheet">

  <title>Twist & Tread</title>
<style>
    /* Fancy Chatbot Styles */
    #chatbot {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 320px;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      z-index: 9999;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
      border-radius: 12px;
      overflow: hidden;
    }

    #chatbot-header {
      background: linear-gradient(135deg, #8e44ad, #c39bd3);
      color: #fff;
      padding: 12px;
      cursor: pointer;
      font-weight: bold;
      text-align: center;
      font-size: 16px;
    }

    #chatbot-body {
      background: #f9f9f9;
      height: 300px;
      overflow-y: auto;
      border-top: 1px solid #dcdcdc;
      padding: 10px;
      display: none;
    }

    #chatbot-input {
      width: 100%;
      box-sizing: border-box;
      padding: 12px;
      border: none;
      border-top: 1px solid #dcdcdc;
      outline: none;
      font-size: 14px;
      display: none;
    }

    .chat-msg {
      margin: 10px 0;
      padding: 10px 14px;
      border-radius: 20px;
      max-width: 80%;
      line-height: 1.4;
      font-size: 14px;
      display: inline-block;
      clear: both;
    }

    .chat-msg.user {
      background-color: #d1c4e9;
      color: #000;
      float: right;
    }

    .chat-msg.bot {
      background-color: #b39ddb;
      color: #fff;
      float: left;
    }
  </style>
  
</head>

<body>

<header class="page-header">
  <!-- topline -->
  <div class="page-header__topline">
    <div class="container clearfix">

      <div class="currency">
        <a class="currency__change" href="customer/my_account.php?my_orders">
          <?php
          if(!isset($_SESSION['customer_email'])){
              echo "Welcome :Guest"; 
          }
          else
          { 
              echo "Welcome : " . $_SESSION['customer_email'];
          }
          ?>
        </a>
      </div>

      <div class="basket">
        <a href="cart.php" class="btn btn--basket">
          <i class="icon-basket"></i>
          <?php items(); ?> items
        </a>
      </div>

      <ul class="login">
        <li class="login__item">
          <?php
          if(!isset($_SESSION['customer_email'])){
            echo '<a href="customer_register.php" class="login__link">Register</a>';
          } else { 
            echo '<a href="customer/my_account.php?my_orders" class="login__link">My Account</a>';
          }
          ?>  
        </li>

        <li class="login__item">
          <?php
          if(!isset($_SESSION['customer_email'])){
            echo '<a href="checkout.php" class="login__link">Sign In</a>';
          } else { 
            echo '<a href="./logout.php" class="login__link">Logout</a>';
          }
          ?>  
        </li>
      </ul>
      
    </div>
  </div>
  <!-- bottomline -->
  <div class="page-header__bottomline">
    <div class="container clearfix">

      <div class="logo">
        <a class="logo__link" href="index.php" style="margin-top: 0px;">
          <img class="logo__img" src="images/logo2.png" alt="Crochet Logo" width="237" height="19">
        </a>
      </div>

      <nav class="main-nav">
        <ul class="categories">
          <li class="categories__item">
            <a class="categories__link" href="shop.php">
              Shop
            </a>
          </li>
          <li class="categories__item">
            <a class="categories__link" href="localstore.php">
              Local Stores
            </a>
          </li>
          <li class="categories__item">
            <a class="categories__link" href="customer/my_account.php?my_orders">
              My Account
              <i class="icon-down-open-1"></i>
            </a>
            <div class="dropdown dropdown--lookbook">
              <div class="clearfix">
                <div class="dropdown__half">
                  <div class="dropdown__heading">Account Settings</div>
                  <ul class="dropdown__items">
                    <li class="dropdown__item">
                      <a href="#" class="dropdown__link">My Wishlist</a>
                    </li>
                    <li class="dropdown__item">
                      <a href="#" class="dropdown__link">My Orders</a>
                    </li>
                    <li class="dropdown__item">
                      <a href="#" class="dropdown__link">View Shopping Cart</a>
                    </li>
                  </ul>
                </div>
                <div class="dropdown__half">
                  <div class="dropdown__heading"></div>
                  <ul class="dropdown__items">
                    <li class="dropdown__item">
                      <a href="#" class="dropdown__link">Edit Your Account</a>
                    </li>
                    <li class="dropdown__item">
                      <a href="#" class="dropdown__link">Change Password</a>
                    </li>
                    <li class="dropdown__item">
                      <a href="#" class="dropdown__link">Delete Account</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </li>
        </ul>
      </nav>
    </div>
  </div>
</header>

<!-- Your existing homepage content here -->

<!-- Chatbot widget -->
<!-- Chatbot HTML -->
<div id="chatbot">
  <div id="chatbot-header" onclick="toggleChat()">CrochetBot 💬</div>
  <div id="chatbot-body"></div>
  <input id="chatbot-input" type="text" placeholder="Type your message...">
</div>

<script>
  const chatbotHeader = document.getElementById('chatbot-header');
  const chatbotBody = document.getElementById('chatbot-body');
  const chatbotInput = document.getElementById('chatbot-input');

  function toggleChat() {
    const isHidden = chatbotBody.style.display === 'none';
    chatbotBody.style.display = isHidden ? 'block' : 'none';
    chatbotInput.style.display = isHidden ? 'block' : 'none';
    if (isHidden) {
      chatbotInput.focus();
      addBotMessage("Hello! I'm CrochetBot 🧶. Ask me anything about crochet!");
    }
  }

  function addMessage(message, sender) {
    const div = document.createElement('div');
    div.className = 'chat-msg ' + sender;
    div.textContent = message;
    chatbotBody.appendChild(div);
    chatbotBody.scrollTop = chatbotBody.scrollHeight;
  }

  function addBotMessage(message) {
    addMessage(message, 'bot');
  }

  chatbotInput.addEventListener('keypress', function(e) {
    if (e.key === 'Enter' && this.value.trim() !== '') {
      const userMessage = this.value.trim();
      addMessage(userMessage, 'user');
      this.value = '';

      fetch('chatbot.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'message=' + encodeURIComponent(userMessage)
      })
      .then(response => response.json())
      .then(data => {
        addBotMessage(data.reply);
      })
      .catch(() => {
        addBotMessage("Sorry, I couldn't get a response. Please try again later.");
      });
    }
  });
</script>


</body>
</html>
